//
//  main.m
//  Oct25
//
//  Created by Lisa Jenkins on 10/24/12.
//  Copyright (c) 2012 Lisa Jenkins. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Oct25AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([Oct25AppDelegate class]));
    }
}
