//
//  Oct25AppDelegate.m
//  Oct25
//
//  Created by Lisa Jenkins on 10/24/12.
//  Copyright (c) 2012 Lisa Jenkins. All rights reserved.
//

#import "Oct25AppDelegate.h"
#import "View.h"

@implementation Oct25AppDelegate
@synthesize window = _window;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    UIScreen *screen = [UIScreen mainScreen];
    CGRect applicationFrame = screen.applicationFrame;
    CGFloat viewHeight = applicationFrame.size.height/3;
    
    view1 = [[View alloc]
             initWithFrame: CGRectMake (applicationFrame.origin.x, applicationFrame.origin.y, applicationFrame.size.width, viewHeight)
             string: @"Hello World!"
             backgroundColor: [UIColor redColor]
             point:CGPointZero
             font:[UIFont systemFontOfSize:32.0]
             ];
    
    view2 = [[View alloc]
             initWithFrame: CGRectMake (applicationFrame.origin.x, applicationFrame.origin.y + viewHeight, applicationFrame.size.width, viewHeight)
             string: @"Hola Mundo!"
             backgroundColor: [UIColor blueColor]
             point: CGPointZero
             font:[UIFont systemFontOfSize:32.0]
             ];
    
    view3 = [[View alloc]
             initWithFrame: CGRectMake (applicationFrame.origin.x, applicationFrame.origin.y + 2*viewHeight, applicationFrame.size.width, viewHeight)
             string: @"Bonjour Monde!"
             backgroundColor: [UIColor purpleColor]
             point: CGPointZero
             font:[UIFont systemFontOfSize:32.0]
             ];

    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    //self.window.backgroundColor = [UIColor whiteColor];
    
    [self.window addSubview:view1];
    [self.window addSubview:view2];
    [self.window addSubview:view3];
    
    [self.window makeKeyAndVisible];
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    view1.backgroundColor = [UIColor purpleColor];
    [view1 setNeedsDisplay];
    view2.backgroundColor = [UIColor redColor];
    [view2 setNeedsDisplay];
    view3.backgroundColor = [UIColor blueColor];
    [view3 setNeedsDisplay];
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
